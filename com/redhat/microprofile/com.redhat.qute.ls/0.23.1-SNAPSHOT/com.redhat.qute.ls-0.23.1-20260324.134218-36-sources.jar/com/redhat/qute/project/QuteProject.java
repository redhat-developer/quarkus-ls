/*******************************************************************************
* Copyright (c) 2021 Red Hat Inc. and others.
* All rights reserved. This program and the accompanying materials
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Contributors:
*     Red Hat Inc. - initial API and implementation
*******************************************************************************/
package com.redhat.qute.project;

import static com.redhat.qute.ls.template.TemplateFileTextDocumentService.isJdtUri;
import static com.redhat.qute.project.JavaDataModelCache.isSameType;
import static com.redhat.qute.utils.FutureUtils.isFutureLoaded;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.eclipse.lsp4j.CompletionItem;

import com.redhat.qute.commons.DocumentFormat;
import com.redhat.qute.commons.FileUtils;
import com.redhat.qute.commons.InvalidMethodReason;
import com.redhat.qute.commons.JavaElementInfo;
import com.redhat.qute.commons.JavaFieldInfo;
import com.redhat.qute.commons.JavaMemberInfo;
import com.redhat.qute.commons.JavaMethodInfo;
import com.redhat.qute.commons.JavaParameterInfo;
import com.redhat.qute.commons.JavaTypeInfo;
import com.redhat.qute.commons.ProjectFeature;
import com.redhat.qute.commons.ProjectInfo;
import com.redhat.qute.commons.QuteJavadocParams;
import com.redhat.qute.commons.ResolvedJavaTypeInfo;
import com.redhat.qute.commons.TemplateRootPath;
import com.redhat.qute.commons.annotations.TemplateDataAnnotation;
import com.redhat.qute.commons.binary.BinaryTemplate;
import com.redhat.qute.commons.binary.BinaryTemplateInfo;
import com.redhat.qute.commons.binary.QuteBinaryTemplateParams;
import com.redhat.qute.commons.datamodel.DataModelParameter;
import com.redhat.qute.commons.datamodel.DataModelProject;
import com.redhat.qute.commons.datamodel.DataModelTemplate;
import com.redhat.qute.commons.datamodel.QuteDataModelProjectParams;
import com.redhat.qute.commons.datamodel.resolvers.NamespaceResolverInfo;
import com.redhat.qute.commons.datamodel.resolvers.ValueResolverKind;
import com.redhat.qute.commons.jaxrs.JaxRsParamKind;
import com.redhat.qute.commons.jaxrs.RestParam;
import com.redhat.qute.parser.expression.Part;
import com.redhat.qute.parser.injection.InjectionDetector;
import com.redhat.qute.parser.template.LiteralSupport;
import com.redhat.qute.parser.template.Parameter;
import com.redhat.qute.parser.template.Section;
import com.redhat.qute.parser.template.Template;
import com.redhat.qute.parser.template.TemplateConfiguration;
import com.redhat.qute.parser.template.sections.CustomSection;
import com.redhat.qute.parser.template.sections.FragmentSection;
import com.redhat.qute.parser.template.sections.IncludeSection;
import com.redhat.qute.parser.template.sections.TemplatePath;
import com.redhat.qute.project.datamodel.ExtendedDataModelProject;
import com.redhat.qute.project.datamodel.ExtendedDataModelTemplate;
import com.redhat.qute.project.datamodel.resolvers.CustomValueResolver;
import com.redhat.qute.project.datamodel.resolvers.FieldValueResolver;
import com.redhat.qute.project.datamodel.resolvers.MessageValueResolver;
import com.redhat.qute.project.datamodel.resolvers.MethodValueResolver;
import com.redhat.qute.project.datamodel.resolvers.TypeValueResolver;
import com.redhat.qute.project.datamodel.resolvers.ValueResolver;
import com.redhat.qute.project.documents.QuteBinaryTextDocument;
import com.redhat.qute.project.documents.QuteClosedTextDocuments;
import com.redhat.qute.project.documents.SearchInfoQuery;
import com.redhat.qute.project.documents.TemplateValidator;
import com.redhat.qute.project.extensions.CodeLensParticipant;
import com.redhat.qute.project.extensions.CompletionParticipant;
import com.redhat.qute.project.extensions.DataModelTemplateParticipant;
import com.redhat.qute.project.extensions.DefinitionParticipant;
import com.redhat.qute.project.extensions.DiagnosticsParticipant;
import com.redhat.qute.project.extensions.DidChangeWatchedFilesParticipant;
import com.redhat.qute.project.extensions.HoverParticipant;
import com.redhat.qute.project.extensions.InlayHintParticipant;
import com.redhat.qute.project.extensions.ProjectExtension;
import com.redhat.qute.project.extensions.TemplateLanguageInjectionParticipant;
import com.redhat.qute.project.tags.UserTag;
import com.redhat.qute.project.tags.UserTagRegistry;
import com.redhat.qute.project.usages.IncludeUsagesRegistry;
import com.redhat.qute.services.QuteCompletableFutures;
import com.redhat.qute.services.completions.CompletionRequest;
import com.redhat.qute.services.nativemode.JavaTypeAccessibiltyRule;
import com.redhat.qute.services.nativemode.JavaTypeFilter;
import com.redhat.qute.services.nativemode.NativeModeJavaTypeFilter;
import com.redhat.qute.utils.StringUtils;

/**
 * A Qute project.
 *
 * @author Angelo ZERR
 *
 */
public class QuteProject {

	private static final Logger LOGGER = Logger.getLogger(QuteProject.class.getName());

	private static String[] TEMPLATE_VARIANTS = { "", ".html", //
			".qute.html", //
			".json", //
			".qute.json", //
			".txt", //
			".qute.txt", //
			".yaml", //
			".qute.yaml", //
			".yml", //
			".qute.yml" };

	private final String uri;

	private final Path projectFolder;

	private final List<TemplateRootPath> templateRootPaths;

	private final Set<Path> sourcePaths;

	private final QuteClosedTextDocuments closedDocuments;

	// Map which stores opened/closed documents identified by template uri.
	private final Map<Path /* template uri */, QuteTextDocument> sourceDocuments;

	// Map which stores binary template documents identified by template uri.
	private final Map<String /* template uri */, QuteTextDocument> binaryDocuments;

	private final Map<String /* template id */, List<QuteTextDocument>> documentsByTemplateId;

	private final Map<String /* Full qualified name of Java class */, CompletableFuture<ResolvedJavaTypeInfo>> resolvedJavaTypes;

	private Map<String /* Full qualified name of Java class */, JavaTypeAccessibiltyRule> targetAnnotations;

	private CompletableFuture<List<BinaryTemplateInfo>> binaryTemplatesFuture;

	private CompletableFuture<ExtendedDataModelProject> dataModelProjectFuture;

	private final QuteProjectRegistry projectRegistry;

	private final UserTagRegistry tagRegistry;

	private final NativeModeJavaTypeFilter filterInNativeMode;

	private final TemplateValidator validator;

	private final JavaDataModelCache javaCache;

	private List<QuteProject> projectDependencies;

	// Project extensions
	private final Map<String, ProjectExtension> extensions;

	private final Set<ProjectFeature> projectFeatures;

	// Participants
	private final Collection<CodeLensParticipant> codeLensParticipants;
	private final Collection<CompletionParticipant> completionParticipants;
	private final Collection<DataModelTemplateParticipant> dataModelTemplateParticipants;
	private final Collection<DidChangeWatchedFilesParticipant> didChangeWatchedFilesParticipants;
	private final Collection<DiagnosticsParticipant> diagnosticsParticipants;
	private final Collection<DefinitionParticipant> definitionParticipants;
	private final Collection<HoverParticipant> hoverParticipants;
	private final Collection<InlayHintParticipant> inlayHintParticipants;
	private final Collection<TemplateLanguageInjectionParticipant> languageInjectionParticipants;

	private final IncludeUsagesRegistry includeUsagesRegistry;

	private CompletableFuture<QuteProject> loadQuteProjectFuture;

	public QuteProject(ProjectInfo projectInfo, QuteProjectRegistry projectRegistry) {
		this.uri = projectInfo.getUri();
		this.projectFolder = FileUtils.createPath(projectInfo.getProjectFolder());
		this.templateRootPaths = projectInfo.getTemplateRootPaths();
		this.sourcePaths = toSourcePaths(projectInfo.getSourceFolders());
		this.projectFeatures = projectInfo.getFeatures();
		this.sourceDocuments = new HashMap<>();
		this.binaryDocuments = new HashMap<>();
		this.documentsByTemplateId = new HashMap<>();
		this.closedDocuments = new QuteClosedTextDocuments(this, sourceDocuments);
		this.projectRegistry = projectRegistry;
		this.resolvedJavaTypes = new HashMap<>();
		this.tagRegistry = new UserTagRegistry(this, templateRootPaths);
		this.includeUsagesRegistry = new IncludeUsagesRegistry(this);
		this.filterInNativeMode = new NativeModeJavaTypeFilter(this);
		this.validator = projectRegistry.getValidator();
		this.javaCache = new JavaDataModelCache(this);
		this.projectDependencies = new ArrayList<>();
		// Project extensions
		this.extensions = new HashMap<>();
		this.codeLensParticipants = new ArrayList<>();
		this.completionParticipants = new ArrayList<>();
		this.dataModelTemplateParticipants = new ArrayList<>();
		this.didChangeWatchedFilesParticipants = new ArrayList<>();
		this.diagnosticsParticipants = new ArrayList<>();
		this.definitionParticipants = new ArrayList<>();
		this.hoverParticipants = new ArrayList<>();
		this.inlayHintParticipants = new ArrayList<>();
		this.languageInjectionParticipants = new ArrayList<>();
		Iterator<ProjectExtension> extensions = ServiceLoader.load(ProjectExtension.class).iterator();
		while (extensions.hasNext()) {
			try {
				registerExtension(extensions.next());
			} catch (ServiceConfigurationError e) {
				LOGGER.log(Level.SEVERE, "Error while instantiating extension", e);
			}
		}
	}

	void registerExtension(ProjectExtension extension) {
		try {
			extensions.put(extension.getId(), extension);
			if (extension instanceof CodeLensParticipant) {
				codeLensParticipants.add((CodeLensParticipant) extension);
			}
			if (extension instanceof CompletionParticipant) {
				completionParticipants.add((CompletionParticipant) extension);
			}
			if (extension instanceof DidChangeWatchedFilesParticipant) {
				didChangeWatchedFilesParticipants.add((DidChangeWatchedFilesParticipant) extension);
			}
			if (extension instanceof DataModelTemplateParticipant) {
				dataModelTemplateParticipants.add((DataModelTemplateParticipant) extension);
			}
			if (extension instanceof DiagnosticsParticipant) {
				diagnosticsParticipants.add((DiagnosticsParticipant) extension);
			}
			if (extension instanceof DefinitionParticipant) {
				definitionParticipants.add((DefinitionParticipant) extension);
			}
			if (extension instanceof HoverParticipant) {
				hoverParticipants.add((HoverParticipant) extension);
			}
			if (extension instanceof InlayHintParticipant) {
				inlayHintParticipants.add((InlayHintParticipant) extension);
			}
			if (extension instanceof TemplateLanguageInjectionParticipant) {
				languageInjectionParticipants.add((TemplateLanguageInjectionParticipant) extension);
			}
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Error while initializing extension <" + extension.getClass().getName() + ">", e);
		}
	}

	void unregisterExtension(ProjectExtension extension) {
		try {
			extensions.remove(extension.getId());
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, "Error while stopping extension <" + extension.getClass().getName() + ">", e);
		}
	}

	public ProjectExtension getExtension(String id) {
		return extensions.get(id);
	}

	public CompletableFuture<QuteProject> load() {
		if (isQuteProjectLoaded()) {
			return loadQuteProjectFuture;
		}
		return loadSync();
	}

	private synchronized CompletableFuture<QuteProject> loadSync() {
		if (isQuteProjectLoaded()) {
			return loadQuteProjectFuture;
		}

		ProgressSupport progressSupport = projectRegistry.getProgressSupportProvider().get();
		ProgressContext progressContext = progressSupport != null ? new ProgressContext(progressSupport) : null;
		String projectName = getUri();

		if (progressContext != null) {
			progressContext.startProgress("Loading '" + projectName + "' project",
					"Trying to load '" + projectName + "' as Qute project.");
		}

		if (progressContext != null) {
			progressContext.report("Loading binary templates for '" + projectName + "' Qute project.", 10);
		}

		loadQuteProjectFuture = this.getBinaryTemplates() //
				.thenCompose(binaryTemplates -> {
					if (progressContext != null) {
						progressContext.report("Loading data model for '" + projectName + "' Qute project.", 20);
					}

					return this.getDataModelProject() //
							.thenCompose(dataModel -> {
								if (progressContext != null) {
									progressContext.report(
											"Loading Qute templates for '" + projectName + "' Qute project.", 40);
								}

								// Register use tags
								registerUserTags();

								// Load closed templates
								closedDocuments.loadClosedTemplatesIfNeeded(progressContext);

								if (progressContext != null) {
									progressContext.endProgress();
								}

								return CompletableFuture.completedFuture(this);
							}).exceptionally((a) -> {
								if (progressContext != null) {
									progressContext.endProgress();
								}
								return this;
							});

				}).exceptionally((a) -> {
					if (progressContext != null) {
						progressContext.endProgress();
					}
					return this;
				});
		loadQuteProjectFuture.thenAccept(unused -> {
			validateClosedTemplates(progressContext);
		});
		return loadQuteProjectFuture;
	}

	private boolean isQuteProjectLoaded() {
		return isFutureLoaded(loadQuteProjectFuture);
	}

	private static Set<Path> toSourcePaths(Set<String> sourceFolders) {
		if (sourceFolders == null || sourceFolders.isEmpty()) {
			return Collections.emptySet();
		}
		return sourceFolders //
				.stream() //
				.map(uri -> FileUtils.createPath(uri)) //
				.filter(Objects::nonNull)//
				.collect(Collectors.toSet());
	}

	public void validateClosedTemplates(ProgressContext progressContext) {
		if (validator != null) {
			// Load closed document if needed and validate all closed documents when data
			// model is ready.
			for (QuteTextDocument document : sourceDocuments.values()) {
				if (!document.isOpened()) {
					validator.triggerValidationFor(document);
				}
			}
		}
	}

	public QuteProjectRegistry getProjectRegistry() {
		return projectRegistry;
	}

	/**
	 * Returns the templates base dir folder of the project (ex :
	 * src/main/resources/templates).
	 *
	 * @return the templates base dir folder of the project (ex :
	 *         src/main/resources/templates).
	 */
	public List<TemplateRootPath> getTemplateRootPaths() {
		return templateRootPaths;
	}

	/**
	 * Returns the template id of the given template file path.
	 * 
	 * @param templateFilePath the Qute template file path.
	 * 
	 * @return the template id of the given template file path.
	 */
	public String getTemplateId(Path templateFilePath) {
		TemplateRootPath rootPath = findTemplateRootPathFor(templateFilePath);
		if (rootPath != null) {
			try {
				boolean forceAsUserTag = rootPath.isOnlyTags();
				Path basePath = rootPath.getBasePath();
				return getTemplateId(basePath.relativize(templateFilePath).toString().replace('\\', '/'),
						forceAsUserTag);
			} catch (Exception e) {
				// Do nothing
			}
		}
		return getTemplateId(templateFilePath.getFileName().toString(), false);
	}

	public TemplateRootPath findTemplateRootPathFor(Path templateFilePath) {
		if (templateFilePath == null || templateRootPaths == null) {
			return null;
		}
		for (TemplateRootPath rootPath : templateRootPaths) {
			Path basePath = rootPath.getBasePath();
			if (basePath != null) {
				if (templateFilePath.startsWith(basePath)) {
					try {
						return rootPath;
					} catch (Exception e) {
						// Do nothing
					}
				}
			}
		}
		return null;
	}

	private static String getTemplateId(String templateId, boolean forceAsUserTag) {
		if (forceAsUserTag && !templateId.startsWith(TemplateRootPath.TAGS_DIR + "/")) {
			return TemplateRootPath.TAGS_DIR + "/" + templateId;
		}
		return templateId;
	}

	/**
	 * Returns true if the document retrieved by template id is opened and false
	 * otherwise.
	 * 
	 * @param templateId the template id.
	 * 
	 * @return true if the document retrieved by template id is opened and false
	 *         otherwise.
	 */
	public boolean isTemplateOpened(Path templatePath) {
		QuteTextDocument document = findSourceDocument(templatePath);
		return document != null && document.isOpened();
	}

	public QuteTextDocument findSourceDocument(Path templatePath) {
		return sourceDocuments.get(templatePath);
	}

	public QuteTextDocument findBinaryDocument(String uri) {
		return binaryDocuments.get(uri);
	}

	/**
	 * Returns the project Uri.
	 *
	 * @return the project Uri.
	 */
	public String getUri() {
		return uri;
	}

	public Path getProjectFolder() {
		return projectFolder;
	}

	public boolean isInProjectFolder(Path path) {
		return projectFolder != null && path.startsWith(projectFolder);
	}

	public boolean isInTemplateFolders(Path path) {
		for (TemplateRootPath rootPath : getTemplateRootPaths()) {
			Path basePath = rootPath.getBasePath();
			if (basePath != null && path.startsWith(basePath)) {
				return true;
			}
		}
		return false;
	}

	public boolean isInSourceFolders(Path path) {
		for (Path sourcePath : getSourcePaths()) {
			if (path.startsWith(sourcePath)) {
				return true;
			}
		}
		return false;
	}

	public List<QuteProject> getProjectDependencies() {
		return projectDependencies;
	}

	/**
	 * Returns the insert parameter list with the given name
	 * <code>insertParamater</code> ({#insert name}) declared in the template
	 * identified by the given template id and null otherwise.
	 * 
	 * @param templateId      the template id.
	 * @param insertParamater the name of the insert parameter. If the name is
	 *                        equals to {@link SearchInfoQuery#ALL}, the methods
	 *                        will returns all declared insert parameters.
	 * @return the insert parameter list with the given name
	 *         <code>insertParamater</code> ({#insert name}) declared in the
	 *         template identified by the given template id and null otherwise.
	 */
	public List<Parameter> findInsertTagParameter(IncludeSection includeSection, String insertParamater) {
		String templateId = includeSection.getReferencedTemplateId();
		return findInsertTagParameter(templateId, insertParamater);
	}

	public List<Parameter> findInsertTagParameter(String templateId, String insertParamater) {
		QuteTextDocument document = findDocumentByTemplateId(templateId);
		if (document != null) {
			return document.findInsertTagParameter(insertParamater);
		}
		return null;
	}

	public List<Parameter> findInsertTagParameter(TemplatePath templatePath, String insertParamater) {
		String uri = templatePath.getUri();
		if (uri != null) {
			QuteTextDocument document = getBinaryDocument(uri);
			if (document == null) {
				// C:\Users\AngeloZerr\git\quarkus-ls\qute.ls\com.redhat.qute.ls\src\test\resources\projects\roq\src\main\resources\templates\layouts\default.html
				Path filePath = FileUtils.createPath(templatePath.getUri());
				if (filePath != null) {
					document = sourceDocuments.get(filePath);
				}
			}
			if (document != null) {
				return document.findInsertTagParameter(insertParamater);
			}
		}
		return findInsertTagParameter(templatePath.getTemplateId(), insertParamater);
	}

	public List<Section> findCustomSectionsByTag(String tag) {
		List<Section> allSections = new ArrayList<>();
		// from sources
		fillSection(tag, sourceDocuments.values(), allSections);
		// from binary (JARs)
		fillSection(tag, binaryDocuments.values(), allSections);
		return allSections;
	}

	private void fillSection(String tag, Collection<QuteTextDocument> documents, List<Section> allSections) {
		for (QuteTextDocument document : documents) {
			List<CustomSection> sections = document.findCustomSectionsByTag(tag);
			if (sections != null && !sections.isEmpty()) {
				allSections.addAll(sections);
			}
		}
	}

	public List<FragmentSection> findFragmentSections(String templateId, String fragmentId) {
		QuteTextDocument document = findDocumentByTemplateId(templateId);
		List<FragmentSection> fragments = document != null ? document.findFragmentSectionById(fragmentId) : null;
		return fragments != null ? fragments : Collections.emptyList();
	}

	public String findTemplateUriByTemplateId(String templateId) {
		QuteTextDocument document = findDocumentByTemplateId(templateId);
		return document != null ? document.getUri() : null;
	}

	public QuteTextDocument findDocumentByTemplateId(String templateId) {
		if (templateId.indexOf('.') != -1) {
			// ex: base.html
			return findDocumentByTemplateIdInCache(templateId);
		}

		// ex : base
		QuteTextDocument binaryDocument = null;
		for (String variant : getTemplateVariants()) {
			String id = templateId + variant;
			QuteTextDocument document = findDocumentByTemplateIdInCache(id);
			if (document != null) {
				return document;
			}
			if (binaryDocument == null) {
				binaryDocument = findDocumentByTemplateIdInCache(id);
			}
		}
		return binaryDocument;
	}

	private QuteTextDocument findDocumentByTemplateIdInCache(String templateId) {
		List<QuteTextDocument> cache = documentsByTemplateId.get(templateId);
		if (cache != null && !cache.isEmpty()) {
			return cache.get(0);
		}
		return null;
	}

	/**
	 * Open a Qute template.
	 *
	 * @param document the Qute template.
	 */
	public void onDidOpenTextDocument(QuteTextDocument document) {
		registerSourceDocument(document);
	}

	/**
	 * Close a Qute template.
	 *
	 * @param document the Qute template.
	 */
	public void onDidCloseTextDocument(QuteTextDocument document) {
		Path templateFilePath = document.getTemplatePath();
		removeDocumentFromCache(templateFilePath);
		closedDocuments.onDidCloseTemplate(templateFilePath);
	}

	/**
	 * Save a Qute template.
	 *
	 * @param document the Qute template.
	 */
	public void onDidSaveTextDocument(QuteTextDocument document) {
		document.save();
	}

	/**
	 * Delete a Qute template file.
	 *
	 * @param templateFilePath the Qute template file path.
	 */
	public QuteTextDocument onDidDeleteTemplate(Path templateFilePath) {
		QuteTextDocument document = removeDocumentFromCache(templateFilePath);
		return document;
	}

	private QuteTextDocument removeDocumentFromCache(Path templateFilePath) {
		synchronized (sourceDocuments) {
			QuteTextDocument removedDocument = sourceDocuments.remove(templateFilePath);
			if (removedDocument != null) {
				List<QuteTextDocument> cache = documentsByTemplateId.get(removedDocument.getTemplateId());
				if (cache != null) {
					cache.remove(removedDocument);
				}
				// Evict user tag registry cache + usages for the removed document
				if (removedDocument.isUserTag()) {
					UserTag userTag = removedDocument.getUserTag();
					tagRegistry.unregisterUserTag(userTag);
					tagRegistry.removeUsages(removedDocument);
				}
				// Evict include usages for the removed document
				includeUsagesRegistry.removeUsages(removedDocument);

			}
			return removedDocument;
		}
	}

	/**
	 * Create a Qute template file.
	 *
	 * @param templateFilePath the Qute template file path.
	 */
	public QuteTextDocument onDidCreateTemplate(Path templateFilePath) {
		return closedDocuments.onDidCreateTemplate(templateFilePath);
	}

	/**
	 * Returns list of all opened/closed Qute template document of the project.
	 * 
	 * @return list of all opened/closed Qute template document of the project.
	 */
	public Collection<QuteTextDocument> getSourceDocuments() {
		return sourceDocuments.values();
	}

	/**
	 * Returns list of all binary Qute template document of the project.
	 * 
	 * @return list of all binary Qute template document of the project.
	 */
	public Collection<QuteTextDocument> getBinaryDocuments() {
		return binaryDocuments.values();
	}

	public CompletableFuture<ResolvedJavaTypeInfo> getResolvedJavaType(String typeName) {
		return resolvedJavaTypes.get(typeName);
	}

	void registerResolvedJavaType(String typeName, CompletableFuture<ResolvedJavaTypeInfo> future) {
		resolvedJavaTypes.put(typeName, future);
		future //
				.thenApply(c -> {
					if (targetAnnotations != null) {
						// Update target annotations @TemplateData, @RegisterForReflection
						updateTargetAnnotation(c, targetAnnotations);
					}
					return c;
				});
	}

	public CompletableFuture<List<BinaryTemplateInfo>> getBinaryTemplates() {
		if (!isFutureLoaded(binaryTemplatesFuture)) {
			binaryTemplatesFuture = loadBinaryTemplates();
		}
		return binaryTemplatesFuture;
	}

	private synchronized CompletableFuture<List<BinaryTemplateInfo>> loadBinaryTemplates() {
		if (isFutureLoaded(binaryTemplatesFuture)) {
			return binaryTemplatesFuture;
		}
		QuteBinaryTemplateParams params = new QuteBinaryTemplateParams();
		params.setProjectUri(getUri());
		return getBinaryTemplates(params) //
				.thenApply(binaryTemplates -> {
					// Register binary templates
					registerBinaryTemplates(binaryTemplates);
					return binaryTemplates;
				});
	}

	protected CompletableFuture<List<BinaryTemplateInfo>> getBinaryTemplates(QuteBinaryTemplateParams params) {
		return projectRegistry.getBinaryTemplates(params);
	}

	public CompletableFuture<ExtendedDataModelProject> getDataModelProject() {
		if (!isFutureLoaded(dataModelProjectFuture)) {
			dataModelProjectFuture = loadDataModelProject() //
					.thenApply(model -> {
						for (ProjectExtension extension : getExtensions()) {
							try {
								extension.init(model);
							} catch (Exception e) {
								LOGGER.log(Level.SEVERE,
										"Error while loading project extension '" + extension.getId() + "'", e);
							}
						}
						return model;

					});
		}
		return dataModelProjectFuture;
	}

	private void registerUserTags() {
		for (QuteTextDocument document : sourceDocuments.values()) {
			registerUserTagIfNeeded(document);
		}
		for (QuteTextDocument document : binaryDocuments.values()) {
			registerUserTagIfNeeded(document);
		}
	}

	protected synchronized CompletableFuture<ExtendedDataModelProject> loadDataModelProject() {
		if (isFutureLoaded(dataModelProjectFuture)) {
			return dataModelProjectFuture;
		}
		QuteDataModelProjectParams params = new QuteDataModelProjectParams();
		params.setProjectUri(getUri());
		return getDataModelProject(params) //
				.thenApply(dataModelProject -> {
					if (dataModelProject == null) {
						return null;
					}
					return new ExtendedDataModelProject(dataModelProject, QuteProject.this);
				});
	}

	protected CompletableFuture<DataModelProject<DataModelTemplate<DataModelParameter>>> getDataModelProject(
			QuteDataModelProjectParams params) {
		return projectRegistry.getDataModelProject(params);
	}

	public void resetJavaTypes(Set<String> sources) {
		if (dataModelProjectFuture != null) {
			dataModelProjectFuture.cancel(true);
			dataModelProjectFuture = null;
		}
		if (sources != null && sources.size() > 0) {
			for (String className : sources) {
				resolvedJavaTypes.remove(className);
			}
		} else {
			resolvedJavaTypes.clear();
		}
		targetAnnotations = null;
	}

	/**
	 * Returns the template configuration of the project.
	 *
	 * @return the template configuration of the project.
	 */
	public TemplateConfiguration getTemplateConfiguration() {
		// TODO : load template configuration from JDT side
		return null;
	}

	/**
	 * Returns list of source ('src/main/resources/templates/tags') and list of
	 * binary ('templates.tags') user tags.
	 *
	 * @return list of source ('src/main/resources/templates/tags') and list of
	 *         binary ('templates.tags') user tags.
	 */
	public Collection<UserTag> getUserTags() {
		return tagRegistry.getUserTags();
	}

	public UserTagRegistry getTagRegistry() {
		return tagRegistry;
	}

	/**
	 * Find user tag by the given tagName and null otherwise.
	 *
	 * @param tagName the tag name.
	 *
	 * @return user tag by the given tagName and null otherwise.
	 */
	public UserTag findUserTag(String tagName) {
		if (StringUtils.isEmpty(tagName)) {
			return null;
		}
		// binary + Source tags
		Collection<UserTag> tags = getUserTags();
		for (UserTag userTag : tags) {
			if (tagName.equals(userTag.getName())) {
				return userTag;
			}
		}
		return null;
	}

	/**
	 * Collect user tags suggestions.
	 *
	 * @param completionRequest completion request.
	 * @param prefixFilter      prefix filter.
	 * @param suffixToFind      suffix to found to eat it when completion snippet is
	 *                          applied.
	 * @param completionItems   set of completion items to update
	 */
	public void collectUserTagSuggestions(CompletionRequest completionRequest, String prefixFilter, String suffixToFind,
			Set<CompletionItem> completionItems) {
		tagRegistry.collectUserTagSuggestions(completionRequest, prefixFilter, suffixToFind, completionItems);
	}

	/**
	 * Returns the preferred tags dir (ex : src/main/resources/templates/tags)
	 * directory and null otherwise.
	 * 
	 * @return the preferred tags dir (ex : src/main/resources/templates/tags)
	 *         directory and null otherwise.
	 */
	public Path getPreferredTagsDir() {
		return tagRegistry.getPreferredTagsDir();
	}

	public JavaTypeAccessibiltyRule getJavaTypeAccessibiltyInNativeMode(String javaTypeName) {
		if (getJavaTypesSupportedInNativeMode().contains(javaTypeName)) {
			return JavaTypeAccessibiltyRule.ALLOWED_WITHOUT_RESTRICTION;
		}

		// Native images mode : the java reflection is supported only if the Java type
		// is
		// annotated with:
		// - @TemplateData
		// - @RegisterForReflection

		// Case 1 : Item
		// javaType = Item
		// @TemplateData
		// public class Item
		//
		// Or
		//
		// @RegisterForReflection
		// public class Item
		// return Arrays.asList(javaType);

		// Case 1 : BigDecimal
		// javaType = BigDecimal
		// @TemplateData(target = BigDecimal.class)
		// public class Item
		//
		// Or
		//
		// @RegisterForReflection(targets = {BigDecimal.class})
		// public class Item
		if (targetAnnotations == null) {
			targetAnnotations = loadTargetAnnotations();
		}
		return targetAnnotations.get(javaTypeName);
	}

	private synchronized Map<String, JavaTypeAccessibiltyRule> loadTargetAnnotations() {
		if (targetAnnotations != null) {
			return targetAnnotations;
		}

		Map<String /* Full qualified name of Java class */, JavaTypeAccessibiltyRule> targetAnnotations = new HashMap<>();
		resolvedJavaTypes.values().forEach(future -> {
			updateTargetAnnotation(future.getNow(null), targetAnnotations);
		});
		return targetAnnotations;
	}

	private void updateTargetAnnotation(ResolvedJavaTypeInfo baseType,
			Map<String /* Full qualified name of Java class */, JavaTypeAccessibiltyRule> targetAnnotations) {
		if (baseType == null) {
			return;
		}
		if (baseType.getTemplateDataAnnotations() != null && !baseType.getTemplateDataAnnotations().isEmpty()) {
			// Loop for @TemplateData
			for (TemplateDataAnnotation annotation : baseType.getTemplateDataAnnotations()) {
				// Merge information about @TemplateData (ignore, etc) in the proper
				// JavaTypeAccessResult
				String target = StringUtils.isEmpty(annotation.getTarget()) ? baseType.getName()
						: annotation.getTarget();
				JavaTypeAccessibiltyRule result = getJavaTypeAccessibiltyRule(target, targetAnnotations);
				result.merge(annotation);
			}
		}
		if (baseType.getRegisterForReflectionAnnotation() != null) {
			// Merge information about @RegisterForReflection (fields, etc) in the proper
			// JavaTypeAccessResult
			List<String> targets = baseType.getRegisterForReflectionAnnotation().getTargets();
			if (targets != null && !targets.isEmpty()) {
				for (String target : targets) {
					JavaTypeAccessibiltyRule result = getJavaTypeAccessibiltyRule(target, targetAnnotations);
					result.merge(baseType.getRegisterForReflectionAnnotation());
				}
			} else {
				String target = baseType.getName();
				JavaTypeAccessibiltyRule result = getJavaTypeAccessibiltyRule(target, targetAnnotations);
				result.merge(baseType.getRegisterForReflectionAnnotation());
			}
		}
	}

	private static JavaTypeAccessibiltyRule getJavaTypeAccessibiltyRule(String target,
			Map<String, JavaTypeAccessibiltyRule> targetAnnotations) {
		return targetAnnotations.computeIfAbsent(target, (x -> new JavaTypeAccessibiltyRule()));
	}

	public JavaTypeFilter getJavaTypeFilterInNativeMode() {
		return filterInNativeMode;
	}

	public Collection<? extends String> getJavaTypesSupportedInNativeMode() {
		ExtendedDataModelProject dataModel = getDataModelProject().getNow(null);
		if (dataModel == null) {
			return Collections.emptySet();
		}
		return dataModel.getJavaTypesSupportedInNativeMode();
	}

	public void dispose() {
	}

	/**
	 * Returns all supported file extension for a Qute template (*.html, *.txt,
	 * etc).
	 * 
	 * @return all supported file extension for a Qute template (*.html, *.txt,
	 *         etc).
	 */
	public String[] getTemplateVariants() {
		return TEMPLATE_VARIANTS;
	}

	public CompletableFuture<ResolvedJavaTypeInfo> resolveJavaType(Part part) {
		return javaCache.resolveJavaType(part);
	}

	CompletableFuture<ResolvedJavaTypeInfo> wrap2(CompletableFuture<ResolvedJavaTypeInfo> future) {
		if (future.isDone()) {
			ResolvedJavaTypeInfo resolvedJavaType = future.getNow(null);
			return wrap(resolvedJavaType);
		}
		return future.thenCompose(resolvedJavaType -> wrap(resolvedJavaType));
	}

	CompletableFuture<ResolvedJavaTypeInfo> wrap(ResolvedJavaTypeInfo resolvedJavaType) {
		if (resolvedJavaType != null && resolvedJavaType.isWrapperType()) {
			List<JavaParameterInfo> types = resolvedJavaType.getTypeParameters();
			if (types != null && !types.isEmpty()) {
				// java.util.concurrent.CompletableFuture<java.util.List<org.acme.Item>>
				JavaParameterInfo type = types.get(0);
				String javaTypeToResolve = type.getType(); // java.util.List<org.acme.Item>
				// Here
				// - javaTypeToResolve = java.util.List<org.acme.Item>
				// - iterTypeName = org.acme.Item
				return resolveJavaType(javaTypeToResolve);
			}
		}
		return CompletableFuture.completedFuture(resolvedJavaType);
	}

	public ResolvedJavaTypeInfo resolveJavaTypeSync(String className) {
		return resolveJavaType(className).getNow(QuteCompletableFutures.RESOLVING_JAVA_TYPE);
	}

	public CompletableFuture<ResolvedJavaTypeInfo> resolveJavaType(String className) {
		return javaCache.resolveJavaType(className);
	}

	public CompletableFuture<ResolvedJavaTypeInfo> resolveJavaType(String className, boolean wrap) {
		return javaCache.resolveJavaType(className, wrap);
	}

	public ResolvedJavaTypeInfo resolveJavaTypeSync(Parameter parameter) {
		return resolveJavaType(parameter).getNow(QuteCompletableFutures.RESOLVING_JAVA_TYPE);
	}

	public CompletableFuture<ResolvedJavaTypeInfo> resolveJavaType(Parameter parameter) {
		return javaCache.resolveJavaType(parameter);
	}

	public InvalidMethodReason getInvalidMethodReason(String property, ResolvedJavaTypeInfo resolvedType) {
		if (resolvedType == null) {
			return InvalidMethodReason.Unknown;
		}
		// Search in the java root type
		InvalidMethodReason reason = resolvedType.getInvalidMethodReason(property);
		if (reason != null) {
			return reason;
		}

		if (resolvedType.getExtendedTypes() != null) {
			// Search in extended types
			for (String extendedType : resolvedType.getExtendedTypes()) {
				ResolvedJavaTypeInfo resolvedExtendedType = resolveJavaTypeSync(extendedType);
				if (!QuteCompletableFutures.isResolvingJavaTypeOrNull(resolvedExtendedType)) {
					reason = resolvedExtendedType.getInvalidMethodReason(property);
					if (reason != null) {
						return reason;
					}
				}
			}
		}
		return null;
	}

	public JavaMemberResult findProperty(Part part, ResolvedJavaTypeInfo baseType, boolean nativeMode) {
		return findProperty(baseType, part.getPartName(), nativeMode);
	}

	/**
	 * Returns the Java method / field from the given Java type
	 * <code>baseType</code> which matches the given property name
	 * <code>property</code>.
	 *
	 * @param baseType   the Java base object type.
	 * @param property   the property name to search.
	 * @param nativeMode the native image mode.
	 * @param projectUri the project Uri.
	 *
	 * @return the Java method / field from the given Java type
	 *         <code>baseType</code> which matches the given property name
	 *         <code>property</code>.
	 */
	private JavaMemberResult findProperty(ResolvedJavaTypeInfo baseType, String property, boolean nativeMode) {
		JavaMemberResult result = new JavaMemberResult();

		if (!nativeMode) {

			// Find member with Java reflection.
			JavaMemberInfo member = findPropertyWithJavaReflection(baseType, property);
			if (member != null) {
				result.setMember(member);
				return result;
			}

			// Find member with value resolvers.
			member = findValueResolver(baseType, property);
			if (member != null) {
				result.setMember(member);
			}
			return result;
		}

		// Find member with value resolvers.
		JavaMemberInfo member = findValueResolver(baseType, property);
		if (member != null) {
			result.setMember(member);
			return result;
		}

		// Find member with Java reflection.
		member = findPropertyWithJavaReflection(baseType, property);
		if (member != null) {
			result.setMember(member);
			return result;
		}
		return result;
	}

	private JavaMemberInfo findPropertyWithJavaReflection(ResolvedJavaTypeInfo baseType, String property) {
		return findPropertyWithJavaReflection(baseType, property, new HashSet<>());
	}

	/**
	 * Returns the Java member from the given base type which matches the given
	 * property by using Java reflection and null otherwise.
	 *
	 * @param baseType   the Java type.
	 * @param property   the property member.
	 * @param projectUri the project Uri.
	 * @param visited    the java types that have already been visited
	 *
	 * @return the Java member from the given base type which matches the given
	 *         property by using Java reflection and null otherwise.
	 */
	private JavaMemberInfo findPropertyWithJavaReflection(ResolvedJavaTypeInfo baseType, String property,
			Set<ResolvedJavaTypeInfo> visited) {
		if (visited.contains(baseType)) {
			return null;
		}
		visited.add(baseType);

		// Search in the java root type
		String getterMethodName = computeGetterName(property);
		String booleanGetterName = computeBooleanGetterName(property);
		JavaMemberInfo memberInfo = findMember(baseType, property, getterMethodName, booleanGetterName);
		if (memberInfo != null) {
			return memberInfo;
		}
		if (baseType.getExtendedTypes() != null) {
			// Search in extended types
			for (String superType : baseType.getExtendedTypes()) {
				ResolvedJavaTypeInfo resolvedSuperType = resolveJavaTypeSync(superType);
				if (!QuteCompletableFutures.isResolvingJavaTypeOrNull(resolvedSuperType)) {
					JavaMemberInfo superMemberInfo = findPropertyWithJavaReflection(resolvedSuperType, property,
							visited);
					if (superMemberInfo != null) {
						return superMemberInfo;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Returns the member retrieved by the given property and null otherwise.
	 *
	 * @param property the property
	 * @return the member retrieved by the given property and null otherwise.
	 */
	private JavaMemberInfo findMember(ResolvedJavaTypeInfo resolvedType, String propertyOrMethodName,
			String getterMethodName, String booleanGetterName) {
		JavaFieldInfo fieldInfo = findField(resolvedType, propertyOrMethodName);
		if (fieldInfo != null) {
			return fieldInfo;
		}
		return findMethod(resolvedType, propertyOrMethodName, getterMethodName, booleanGetterName);
	}

	/**
	 * Returns the member field retrieved by the given name and null otherwise.
	 *
	 * @param baseType  the Java base type.
	 * @param fieldName the field name
	 *
	 * @return the member field retrieved by the given property and null otherwise.
	 */
	protected static JavaFieldInfo findField(ResolvedJavaTypeInfo baseType, String fieldName) {
		List<JavaFieldInfo> fields = baseType.getFields();
		if (fields == null || fields.isEmpty() || isEmpty(fieldName)) {
			return null;
		}
		for (JavaFieldInfo field : fields) {
			if (fieldName.equals(field.getName())) {
				return field;
			}
		}
		return null;
	}

	/**
	 * Returns the member method retrieved by the given property or method name and
	 * null otherwise.
	 *
	 * @param baseType          the Java base type.
	 * @param methodName        property or method name.
	 * @param getterMethodName  the getter method name.
	 * @param booleanGetterName the boolean getter method name.
	 *
	 * @return the member field retrieved by the given property or method name and
	 *         null otherwise.
	 */
	protected static JavaMethodInfo findMethod(ResolvedJavaTypeInfo baseType, String methodName,
			String getterMethodName, String booleanGetterName) {
		List<JavaMethodInfo> methods = baseType.getMethods();
		if (methods == null || methods.isEmpty() || isEmpty(methodName)) {
			return null;
		}
		for (JavaMethodInfo method : methods) {
			if (isMatchMethod(method, methodName, getterMethodName, booleanGetterName)) {
				return method;
			}
		}
		return null;
	}

	/**
	 * Returns the Java method from the given Java type <code>baseType</code> which
	 * matches the given method name <code>methodName</code> with the given
	 * parameter types <code>parameterTypes</code>.
	 *
	 * @param baseType       the Java base object type.
	 * @param namespace      the namespace part and null otherwise.
	 * @param methodName     the method name to search.
	 * @param parameterTypes the parameter types of the method to search.
	 * @param nativeMode     the native image mode.
	 * @param projectUri     the project Uri.
	 *
	 * @return the Java method from the given Java type <code>baseType</code> which
	 *         matches the given method name <code>methodName</code> with the given
	 *         parameter types <code>parameterTypes</code>.
	 */
	public JavaMemberResult findMethod(ResolvedJavaTypeInfo baseType, String namespace, String methodName,
			List<ResolvedJavaTypeInfo> parameterTypes, boolean nativeMode) {
		// Search in the java root type
		JavaMemberResult result = new JavaMemberResult();

		if (!nativeMode && baseType != null) {
			// In NO native image mode, search with Java reflection at the begin
			if (findMethod(baseType, methodName, parameterTypes, result)) {
				return result;
			}
		}

		// Search in template extension value resolvers retrieved by @TemplateExtension
		List<MethodValueResolver> dynamicResolvers = getMethodValueResolvers().getNow(null);
		if (findMethodResolver(baseType, namespace, methodName, parameterTypes, dynamicResolvers, result)) {
			return result;
		}

		if (baseType != null) {
			// Search in static value resolvers (ex : orEmpty, take, etc)
			List<MethodValueResolver> staticResolvers = projectRegistry.getCommmonsResolvers();
			if (findMethodResolver(baseType, null, methodName, parameterTypes, staticResolvers, result)) {
				return result;
			}

			if (nativeMode) {
				// In native image mode, search with Java reflection at the end
				if (findMethod(baseType, methodName, parameterTypes, result)) {
					return result;
				}
			}
		}

		return result;
	}

	private boolean findMethod(ResolvedJavaTypeInfo baseType, String methodName,
			List<ResolvedJavaTypeInfo> parameterTypes, JavaMemberResult result) {
		return findMethod(baseType, methodName, parameterTypes, result, new HashSet<>());
	}

	private boolean findMethod(ResolvedJavaTypeInfo baseType, String methodName,
			List<ResolvedJavaTypeInfo> parameterTypes, JavaMemberResult result, Set<ResolvedJavaTypeInfo> visited) {
		if (visited.contains(baseType)) {
			return false;
		}
		visited.add(baseType);

		if (isEmpty(methodName)) {
			return false;
		}
		List<JavaMethodInfo> methods = baseType.getMethods();
		if (methods != null && !methods.isEmpty()) {
			for (JavaMethodInfo method : methods) {
				if (isMatchMethod(method, methodName, null, null)) {
					// The current method matches the method name.

					// Check if the current method matches the parameters.
					boolean matchParameters = isMatchParameters(method, parameterTypes);
					if (result.getMember() == null || matchParameters) {
						result.setMember(method);
						result.setMatchParameters(matchParameters);
						result.setMatchVirtualMethod(true);
					}
					if (matchParameters) {
						// The current method matches the method name and and parameters types,stop the
						// search
						return true;
					}
				}
			}
		}
		if (baseType.getExtendedTypes() != null) {
			// Search in extended types
			for (String superType : baseType.getExtendedTypes()) {
				ResolvedJavaTypeInfo resolvedSuperType = resolveJavaTypeSync(superType);
				if (!QuteCompletableFutures.isResolvingJavaTypeOrNull(resolvedSuperType)) {
					if (findMethod(resolvedSuperType, methodName, parameterTypes, result, visited)) {
						return true;
					}
				}
			}
		}
		return false;
	}

	private boolean findMethodResolver(ResolvedJavaTypeInfo baseType, String namespace, String methodName,
			List<ResolvedJavaTypeInfo> parameterTypes, List<MethodValueResolver> resolvers, JavaMemberResult result) {
		if (resolvers == null) {
			return false;
		}
		for (MethodValueResolver resolver : resolvers) {
			if (isMatchMethod(resolver, methodName) || isMatchValueResolver(resolver, methodName)) {
				// The current resolver matches the method name.
				if (namespace != null || resolver.getNamespace() != null) {
					if (Objects.equals(namespace, resolver.getNamespace())) {
						// Check if the current resolver matches the parameters.
						boolean matchParameters = isMatchParameters(resolver, parameterTypes);
						if (matchParameters || (result.getMember() == null && !resolver.isMatchNameAny())) {
							result.setMember(resolver);
							result.setMatchVirtualMethod(true);
							result.setMatchParameters(matchParameters);
						}
						if (matchParameters) {
							return true;
						}
					}
				} else {
					if (baseType == null) {
						return false;
					}
					// Check if the baseType matches the type of the first parameter of the current
					// resolver.
					boolean matchVirtualMethod = matchResolver(baseType, resolver);
					boolean matchParameters = false;
					if (matchVirtualMethod) {
						// Check if the current resolver matches the parameters.
						matchParameters = isMatchParameters(resolver, parameterTypes);
					}
					boolean matchResolver = matchParameters && matchVirtualMethod;
					if (matchResolver || (result.getMember() == null && !resolver.isMatchNameAny())) {
						result.setMember(resolver);
						result.setMatchParameters(matchParameters);
						result.setMatchVirtualMethod(matchVirtualMethod);
					}
					if (matchResolver) {
						// The current resolver matches the method name, the parameters types and the
						// virtual method,stop the search
						return true;
					}
				}
			}
		}
		return false;
	}

	private boolean isMatchParameters(JavaMethodInfo method, List<ResolvedJavaTypeInfo> parameterTypes) {
		int nbParameters = method.getApplicableParameters().size();
		int declaredNbParameters = parameterTypes.size();
		JavaParameterInfo lastParameter = method.hasParameters()
				? method.getParameterAt(method.getParameters().size() - 1)
				: null;
		boolean varargs = lastParameter != null && lastParameter.isVarargs();
		if (varargs) {
			if (declaredNbParameters == 0) {
				// Method defines just a varargs parameter
				if (parameterTypes.isEmpty()) {
					// with varargs, the parameter is optional
					return true;
				}
			}
			if (declaredNbParameters < nbParameters) {
				return false;
			}
		} else if (declaredNbParameters != nbParameters) {
			boolean valid = false;
			if (method.getJaxRsMethodKind() != null) {
				// Renarde parameters validation rules:
				// 1) all parameters which are annotated with @RestPath (or @PathParam) are
				// considered as required
				// 2) all parameters which are annotated with @RestQuery (or @QueryParam) are
				// optional
				// 3) all parameters which are annotated with @RestForm (or @FormParam) cannot
				// appear in the method of uri.
				int nbRequiredParameters = 0;
				int nbOptionalParameters = 0;
				for (int i = 0; i < nbParameters - (varargs ? 1 : 0); i++) {
					JavaParameterInfo parameterInfo = method.getParameters().get(i);
					RestParam restParam = method.getRestParameter(parameterInfo.getName());
					if (restParam != null) {
						if (restParam.getParameterKind() == JaxRsParamKind.PATH) {
							nbRequiredParameters++;
						} else if (restParam.getParameterKind() == JaxRsParamKind.QUERY) {
							nbOptionalParameters++;
						}
					}
				}
				if (declaredNbParameters < nbRequiredParameters) {
					return false;
				}
				if (declaredNbParameters > nbRequiredParameters + nbOptionalParameters) {
					return false;
				}
				nbParameters = declaredNbParameters;
				valid = true;
			}
			if (!valid) {
				return false;
			}
		}

		// Validate all mandatory parameters (without varargs)
		for (int i = 0; i < nbParameters - (varargs ? 1 : 0); i++) {
			JavaParameterInfo parameterInfo = method.getApplicableParameters().get(i);
			ResolvedJavaTypeInfo result = parameterTypes.get(i);

			// If the type info isn't available, assume the type matches.
			// This is helpful eg. when getting the docs for a method whose
			// parameters haven't been input correctly yet.
			if (result != null) {
				JavaTypeInfo parameterType = parameterInfo.getJavaType();
				if (!isMatchType(result, parameterType)) {
					return false;
				}
			}
		}

		if (varargs && lastParameter != null) {
			// Validate varargs parameters
			for (int i = nbParameters - 1; i < declaredNbParameters; i++) {
				JavaTypeInfo parameterType = lastParameter.getVarArgJavaType();
				ResolvedJavaTypeInfo result = parameterTypes.get(i);
				// If the type info isn't available, assume the type matches
				// (see note above)
				if (result != null) {
					if (!isMatchType(result, parameterType)) {
						return false;
					}
				}
			}
		}

		return true;
	}

	protected static String computeGetterName(String propertyOrMethodName) {
		return "get" + (propertyOrMethodName.charAt(0) + "").toUpperCase()
				+ propertyOrMethodName.substring(1, propertyOrMethodName.length());
	}

	protected static String computeBooleanGetterName(String propertyOrMethodName) {
		return "is" + (propertyOrMethodName.charAt(0) + "").toUpperCase()
				+ propertyOrMethodName.substring(1, propertyOrMethodName.length());
	}

	private static boolean isMatchMethod(JavaMethodInfo method, String propertyOrMethodName) {
		String getterMethodName = computeGetterName(propertyOrMethodName);
		String booleanGetterName = computeBooleanGetterName(propertyOrMethodName);
		return isMatchMethod(method, propertyOrMethodName, getterMethodName, booleanGetterName);
	}

	private static boolean isMatchMethod(JavaMethodInfo method, String propertyOrMethodName, String getterMethodName,
			String booleanGetterName) {
		String methodName = method.getMethodName();
		if (propertyOrMethodName.equals(methodName) || (getterMethodName != null && getterMethodName.equals(methodName))
				|| (booleanGetterName != null && booleanGetterName.equals(methodName))) {
			return true;
		}
		return false;
	}

	private static boolean isEmpty(String value) {
		return value == null || value.isEmpty();
	}

	public MethodValueResolver findValueResolver(ResolvedJavaTypeInfo baseType, String property) {
		// Search in value resolver
		String literalType = LiteralSupport.getLiteralJavaType(property);
		if (literalType != null) {
			// ex : @java.lang.Integer(base : T[]) : T (see qute-resolvers.jsonc)
			property = "@" + literalType;
		}
		List<MethodValueResolver> resolvers = getResolversFor(baseType);
		for (MethodValueResolver resolver : resolvers) {
			if (isMatchMethod(resolver, property) || isMatchValueResolver(resolver, property)) {
				return resolver;
			}
		}
		return null;
	}

	private static boolean isMatchValueResolver(ValueResolver resolver, String property) {
		if (property == null) {
			return false;
		}
		String named = resolver.getNamed();
		if (named != null) {
			return named.equals(property);
		}

		List<String> matchNames = resolver.getMatchNames();
		if (matchNames != null) {
			for (String matchName : matchNames) {
				if (ValueResolver.MATCH_NAME_ANY.equals(matchName) || matchName.equals(property)) {
					return true;
				}
			}
		}
		return property.equals(resolver.getName());
	}

	public List<MethodValueResolver> getResolversFor(ResolvedJavaTypeInfo javaType) {
		// Search in static value resolvers (ex : orEmpty, take, etc)
		List<MethodValueResolver> matches = new ArrayList<>();
		for (MethodValueResolver resolver : projectRegistry.getCommmonsResolvers()) {
			if (matchResolver(javaType, resolver)) {
				matches.add(resolver);
			}
		}
		// Search in template extension value resolvers retrieved by @TemplateExtension
		List<MethodValueResolver> allResolvers = getMethodValueResolvers().getNow(null);
		if (allResolvers != null) {
			for (MethodValueResolver resolver : allResolvers) {
				if (resolver.getNamespace() == null && matchResolver(javaType, resolver)) {
					matches.add(resolver);
				}
			}
		}
		return matches;
	}

	/**
	 * Returns true if the given java type match the value resolver (if the type
	 * matches the first parameter of the value resolver method) and false
	 * otherwise.
	 *
	 * @param javaType   the java type.
	 * @param resolver   the value resolver.
	 * @param projectUri the project Uri.
	 *
	 * @return true if the given java type match the value resolver (if the type
	 *         matches the first parameter of the value resolver method) and false
	 *         otherwise.
	 */
	private boolean matchResolver(ResolvedJavaTypeInfo javaType, MethodValueResolver resolver) {
		// Example with following signature:
		// "orEmpty(arg : java.util.List<T>) : java.lang.Iterable<T>"
		JavaParameterInfo parameter = resolver.getParameterAt(0); // arg : java.util.List<T>
		if (parameter == null) {
			return false;
		}
		if (parameter.getJavaType().isSingleGenericType()) {
			// - <T>
			// - <T[]>
			return javaType.isArray() == parameter.getJavaType().isArray();
		}
		JavaTypeInfo parameterType = parameter.getJavaType();
		return isMatchType(javaType, parameterType);
	}

	private boolean isMatchType(ResolvedJavaTypeInfo javaType, JavaTypeInfo parameterType) {
		return isMatchType(javaType, parameterType, new HashSet<>());
	}

	private boolean isMatchType(ResolvedJavaTypeInfo javaType, JavaTypeInfo parameterType,
			Set<ResolvedJavaTypeInfo> visited) {
		if (visited.contains(javaType)) {
			return false;
		}
		visited.add(javaType);

		if ("java.lang.Object".equals(parameterType.getSignature())) {
			return true;
		}

		if (isSameType(parameterType, javaType)) {
			return true;
		}

		// class BigItem <- Item <- SmallItem
		// javaType = BigItem => javaType.getExtendedTypes() = [Item]
		if (javaType.getExtendedTypes() != null) {
			// Loop for first level of super types (ex Item)
			for (String superType : javaType.getExtendedTypes()) {
				// Fast check
				if (isSameType(parameterType.getSignature(), superType)) {
					return true;
				}

				// Loop for other levels of super types (ex SmallItem)
				ResolvedJavaTypeInfo resolvedSuperType = resolveJavaTypeSync(superType);
				if (!QuteCompletableFutures.isResolvingJavaTypeOrNull(resolvedSuperType)) {
					if (isMatchType(resolvedSuperType, parameterType, visited)) {
						return true;
					}
				}
			}
		}
		/*
		 * if (!javaType.getTypeParameters().isEmpty()) { ResolvedJavaTypeInfo result =
		 * resolveJavaTypeSync(resolvedTypeName); if
		 * (!QuteCompletableFutures.isResolvingJavaTypeOrNull(result) &&
		 * result.getExtendedTypes() != null) { for (String superType :
		 * result.getExtendedTypes()) { if (isSameType(parameterType, superType)) {
		 * return true; } } } }
		 */
		return false;
	}

	private CompletableFuture<List<MethodValueResolver>> getMethodValueResolvers() {
		return getDataModelProject() //
				.thenApply(dataModel -> {
					if (dataModel == null) {
						return null;
					}
					return dataModel.getMethodValueResolvers();
				});
	}

	/**
	 * Returns the Java member (field or method) from the given Java base type with
	 * the given property and null otherwise.
	 *
	 * @param baseType   the Java base type.
	 * @param property   the member property (field name or getter method name).
	 * @param projectUri the project Uri used to search in the extended Java type.
	 * @return the Java member (field or method) from the given Java base type with
	 *         the given property and null otherwise.
	 */
	public JavaMemberInfo findMember(ResolvedJavaTypeInfo baseType, String property) {
		if (baseType == null) {
			return null;
		}
		JavaMemberInfo member = findPropertyWithJavaReflection(baseType, property);
		if (member != null) {
			return member;
		}
		return findValueResolver(baseType, property);
	}

	public boolean hasNamespace(String namespace) {
		return getAllNamespaces().contains(namespace);
	}

	/**
	 * Return all namespaces from the given Qute project Uri.
	 *
	 * @param projectUri the Qute project Uri
	 *
	 * @return all namespace from the given Qute project Uri.
	 */
	public Set<String> getAllNamespaces() {
		ExtendedDataModelProject dataModel = getDataModelProject().getNow(null);
		return dataModel != null ? dataModel.getAllNamespaces() : Collections.emptySet();
	}

	public CompletableFuture<JavaElementInfo> findJavaElementWithNamespace(String namespace, String partName) {
		return getDataModelProject() //
				.thenApply(dataModel -> {
					if (dataModel == null) {
						return null;
					}
					// Search in types resolvers
					List<TypeValueResolver> typeResolvers = dataModel.getTypeValueResolvers();
					for (TypeValueResolver resolver : typeResolvers) {
						if (isMatchNamespaceResolver(namespace, partName, resolver, dataModel)) {
							return resolver;
						}
					}
					// Search in methods resolvers
					List<MethodValueResolver> methodResolvers = dataModel.getMethodValueResolvers();
					for (MethodValueResolver resolver : methodResolvers) {
						if (isMatchNamespaceResolver(namespace, partName, resolver, dataModel)) {
							return resolver;
						}
					}
					// Search in field resolvers
					List<FieldValueResolver> fieldResolvers = dataModel.getFieldValueResolvers();
					for (FieldValueResolver resolver : fieldResolvers) {
						if (isMatchNamespaceResolver(namespace, partName, resolver, dataModel)) {
							return resolver;
						}
					}
					// Search in custom resolvers
					List<CustomValueResolver> customResolvers = dataModel.getCustomValueResolvers();
					for (CustomValueResolver resolver : customResolvers) {
						if (isMatchNamespaceResolver(namespace, partName, resolver, dataModel)) {
							return resolver;
						}
					}
					return null;
				});
	}

	public CompletableFuture<JavaElementInfo> findGlobalVariableJavaElement(String partName) {
		return getDataModelProject() //
				.thenApply(dataModel -> {
					if (dataModel == null) {
						return null;
					}
					// Search in types resolvers
					List<TypeValueResolver> typeResolvers = dataModel.getTypeValueResolvers();
					for (TypeValueResolver resolver : typeResolvers) {
						if (isMatchGlobalVariableResolver(partName, resolver, dataModel)) {
							return resolver;
						}
					}
					// Search in methods resolvers
					List<MethodValueResolver> methodResolvers = dataModel.getMethodValueResolvers();
					for (MethodValueResolver resolver : methodResolvers) {
						if (isMatchGlobalVariableResolver(partName, resolver, dataModel)) {
							return resolver;
						}
					}
					// Search in field resolvers
					List<FieldValueResolver> fieldResolvers = dataModel.getFieldValueResolvers();
					for (FieldValueResolver resolver : fieldResolvers) {
						if (isMatchGlobalVariableResolver(partName, resolver, dataModel)) {
							return resolver;
						}
					}
					return null;
				});
	}

	public CompletableFuture<MessageValueResolver> findMessageValueResolver(String namespace, String methodName) {
		return getDataModelProject() //
				.thenApply(dataModel -> {
					if (dataModel == null) {
						return null;
					}

					// Search in methods resolvers
					List<MethodValueResolver> methodResolvers = dataModel.getMethodValueResolvers();
					for (MethodValueResolver resolver : methodResolvers) {
						if (resolver.getKind() == ValueResolverKind.Message
								&& isMatchNamespaceResolver(namespace, methodName, resolver, dataModel)) {
							return (MessageValueResolver) resolver;
						}
					}
					return null;
				});
	}

	private static boolean isMatchNamespaceResolver(String namespace, String partName, ValueResolver resolver,
			ExtendedDataModelProject dataModel) {
		return dataModel.getSimilarNamespace(namespace).equals(resolver.getNamespace())
				&& isMatchValueResolver(resolver, partName);
	}

	private static boolean isMatchGlobalVariableResolver(String partName, ValueResolver resolver,
			ExtendedDataModelProject dataModel) {
		return resolver.isGlobalVariable() && isMatchValueResolver(resolver, partName);
	}

	public CompletableFuture<NamespaceResolverInfo> getNamespaceResolverInfo(String namespace) {
		return getDataModelProject() //
				.thenApply(dataModel -> {
					if (dataModel == null) {
						return null;
					}
					return dataModel.getNamespaceResolver(namespace);
				});
	}

	public CompletableFuture<List<ValueResolver>> getGlobalVariables() {
		return getDataModelProject() //
				.thenApply(dataModel -> {
					if (dataModel == null) {
						return null;
					}
					List<ValueResolver> globalVariables = new ArrayList<>();
					for (ValueResolver valueResolver : dataModel.getTypeValueResolvers()) {
						if (valueResolver.isGlobalVariable()) {
							globalVariables.add(valueResolver);
						}
					}
					for (ValueResolver valueResolver : dataModel.getMethodValueResolvers()) {
						if (valueResolver.isGlobalVariable()) {
							globalVariables.add(valueResolver);
						}
					}
					for (ValueResolver valueResolver : dataModel.getFieldValueResolvers()) {
						if (valueResolver.isGlobalVariable()) {
							globalVariables.add(valueResolver);
						}
					}
					return globalVariables;
				});
	}

	public CompletableFuture<List<MessageValueResolver>> getMessageValueResolvers() {
		return getDataModelProject() //
				.thenApply(dataModel -> {
					if (dataModel == null) {
						return null;
					}
					List<MessageValueResolver> messages = new ArrayList<>();
					for (ValueResolver valueResolver : dataModel.getMethodValueResolvers()) {
						if (valueResolver.getKind() == ValueResolverKind.Message) {
							messages.add((MessageValueResolver) valueResolver);
						}
					}
					return messages;
				});
	}

	public CompletableFuture<ExtendedDataModelTemplate> getDataModelTemplate(Template template) {
		return getDataModelProject() //
				.thenApply(dataModel -> {
					if (dataModel == null) {
						return null;
					}
					return dataModel.findDataModelTemplate(template.getUri(), template.isUserTag());
				});
	}

	/**
	 * Returns namespace resolvers from the given Qute project Uri.
	 *
	 * @param projectUri the Qute project Uri
	 *
	 * @return namespace resolvers from the given Qute project Uri.
	 */
	public List<ValueResolver> getNamespaceResolvers(String namespace) {
		ExtendedDataModelProject dataModel = getDataModelProject().getNow(null);
		if (dataModel == null) {
			return Collections.emptyList();
		}

		List<ValueResolver> namespaceResolvers = new ArrayList<>();

		List<TypeValueResolver> allTypeResolvers = dataModel.getTypeValueResolvers();
		if (allTypeResolvers != null) {
			for (ValueResolver resolver : allTypeResolvers) {
				if (isMatchNamespace(resolver, namespace, dataModel)) {
					namespaceResolvers.add(resolver);
				}
			}
		}

		List<MethodValueResolver> allMethodResolvers = dataModel.getMethodValueResolvers();
		if (allMethodResolvers != null) {
			for (ValueResolver resolver : allMethodResolvers) {
				if (isMatchNamespace(resolver, namespace, dataModel)) {
					namespaceResolvers.add(resolver);
				}
			}
		}

		List<FieldValueResolver> allFieldResolvers = dataModel.getFieldValueResolvers();
		if (allFieldResolvers != null) {
			for (ValueResolver resolver : allFieldResolvers) {
				if (isMatchNamespace(resolver, namespace, dataModel)) {
					namespaceResolvers.add(resolver);
				}
			}
		}

		List<CustomValueResolver> allFileResolvers = dataModel.getCustomValueResolvers();
		if (allFileResolvers != null) {
			for (ValueResolver resolver : allFileResolvers) {
				if (isMatchNamespace(resolver, namespace, dataModel)) {
					namespaceResolvers.add(resolver);
				}
			}
		}
		return namespaceResolvers;
	}

	private static boolean isMatchNamespace(ValueResolver resolver, String namespace,
			ExtendedDataModelProject dataModel) {
		if (resolver.getNamespace() == null) {
			return false;
		}
		return namespace == null || dataModel.getSimilarNamespace(namespace).equals(resolver.getNamespace());
	}

	/**
	 * Return all template extensions classes from the given Qute project Uri.
	 *
	 * @param projectUri the Qute project Uri
	 *
	 * @return all template extensions classes from the given Qute project Uri.
	 */
	public Set<String> getAllTemplateExtensionsClasses() {
		ExtendedDataModelProject dataModel = getDataModelProject().getNow(null);
		return dataModel != null ? dataModel.getAllTemplateExtensionsClasses() : Collections.emptySet();
	}

	/**
	 * Returns the documentation for the given member as a completable future.
	 * 
	 * @param javaMemberInfo the member to get the documentation for
	 * @param javaTypeInfo   the type that the member belongs to
	 * @param projectUri     the project that the member is in
	 * @return the documentation for the given member as a completable future
	 */
	public CompletableFuture<String> getJavadoc(JavaMemberInfo javaMemberInfo, JavaTypeInfo javaTypeInfo,
			boolean hasMarkdown) {
		String typeName = javaMemberInfo.getJavaTypeInfo() != null ? javaMemberInfo.getJavaTypeInfo().getName()
				: javaTypeInfo.getName();
		String signature = javaMemberInfo.getGenericMember() == null ? javaMemberInfo.getSignature()
				: javaMemberInfo.getGenericMember().getSignature();
		return projectRegistry.getJavadoc(new QuteJavadocParams(typeName, getUri(), javaMemberInfo.getName(), signature,
				hasMarkdown ? DocumentFormat.Markdown : DocumentFormat.PlainText));
	}

	/**
	 * Returns the source paths (ex: C:/Users/foo/project/src/main/resources) of the
	 * Qute project
	 * 
	 * @return the source paths (ex: C:/Users/foo/project/src/main/resources) of the
	 *         Qute project
	 */
	public Set<Path> getSourcePaths() {
		return sourcePaths;
	}

	/**
	 * Returns the Qute project extension list.
	 * 
	 * @return the Qute project extension list.
	 */
	public Collection<ProjectExtension> getExtensions() {
		return extensions.values();
	}

	public boolean hasProjectFeature(ProjectFeature projectFeature) {
		return projectFeatures != null && projectFeatures.contains(projectFeature);
	}

	// Participants

	public Collection<CodeLensParticipant> getCodeLensParticipants() {
		return codeLensParticipants;
	}

	public Collection<CompletionParticipant> getCompletionParticipants() {
		return completionParticipants;
	}

	public Collection<DataModelTemplateParticipant> getDataModelTemplateParticipants() {
		return dataModelTemplateParticipants;
	}

	public Collection<DefinitionParticipant> getDefinitionParticipants() {
		return definitionParticipants;
	}

	public Collection<DidChangeWatchedFilesParticipant> getDidChangeWatchedFilesParticipants() {
		return didChangeWatchedFilesParticipants;
	}

	public Collection<DiagnosticsParticipant> getDiagnosticsParticipants() {
		return diagnosticsParticipants;
	}

	public Collection<HoverParticipant> getHoverParticipants() {
		return hoverParticipants;
	}

	public Collection<InlayHintParticipant> getInlayHintParticipants() {
		return inlayHintParticipants;
	}

	public Collection<InjectionDetector> getInjectionDetectorsFor(Path path) {
		Collection<TemplateLanguageInjectionParticipant> participants = languageInjectionParticipants;
		if (!participants.isEmpty()) {
			Collection<InjectionDetector> allInjectors = null;
			for (TemplateLanguageInjectionParticipant participant : participants) {
				if (participant.isEnabled()) {
					Collection<InjectionDetector> injectors = participant.getInjectionDetectorsFor(path);
					if (injectors != null && !injectors.isEmpty()) {
						if (allInjectors == null) {
							allInjectors = new ArrayList<>();
						}
						allInjectors.addAll(injectors);
					}
				}
			}
			return allInjectors != null ? allInjectors : Collections.emptyList();
		}
		return Collections.emptyList();
	}

	protected void registerBinaryTemplates(List<BinaryTemplateInfo> binaryTemplates) {
		for (BinaryTemplateInfo binaryTemplate : binaryTemplates) {
			String binaryName = binaryTemplate.getBinaryName();
			Map<String, String> properties = binaryTemplate.getProperties();
			List<BinaryTemplate> templates = binaryTemplate.getTemplates();
			for (BinaryTemplate template : templates) {
				QuteBinaryTextDocument document = new QuteBinaryTextDocument(template, binaryName, properties, this);
				registerBinaryDocument(document);
			}
		}
	}

	public void registerSourceDocument(QuteTextDocument document) {
		QuteTextDocument oldDocument = sourceDocuments.get(document.getTemplatePath());
		if (oldDocument != null) {
			removeDocumentFromCache(oldDocument.getTemplatePath());
		}
		sourceDocuments.put(document.getTemplatePath(), document);
		addInTemplateIdCache(document);
		registerUserTagIfNeeded(document);
	}

	void registerBinaryDocument(QuteTextDocument document) {
		binaryDocuments.put(normalizeUriIfNeeded(document.getUri()), document);
		addInTemplateIdCache(document);
	}

	private void registerUserTagIfNeeded(QuteTextDocument document) {
		if (document.isUserTag()) {
			UserTag tag = document.getUserTag();
			tagRegistry.registerUserTag(tag);
		}
	}

	private void addInTemplateIdCache(QuteTextDocument document) {
		String templateId = document.getTemplateId();
		List<QuteTextDocument> cache = documentsByTemplateId.computeIfAbsent(templateId,
				_unused -> new ArrayList<QuteTextDocument>());
		cache.add(document);
	}

	/**
	 * Returns list of all binary Qute template document of the project.
	 * 
	 * @return list of all binary Qute template document of the project.
	 */
	public QuteTextDocument getBinaryDocument(String uri) {
		return binaryDocuments.get(normalizeUriIfNeeded(uri));
	}

	private static String normalizeUriIfNeeded(String uri) {
		if (isJdtUri(uri)) {
			return normalizeJdtUri(uri);
		}
		return uri;
	}

	// Normalize the URI to a canonical form so that URIs built by our LS
	// and URIs received from vscode-java (didOpen) can be compared reliably.
	private static String normalizeJdtUri(String uri) {
		// vscode-java call didOpen with this Uri
		// jdt://jarentry/templates/tags/bundle.html?%3Dthe-code-site%2FC%3A%5C%2FUsers%5C%2FAngeloZerr%5C%2F.m2%5C%2Frepository%5C%2Fio%5C%2Fquarkiverse%5C%2Fweb-bundler%5C%2Fquarkus-web-bundler-common%5C%2F2.2.0%5C%2Fquarkus-web-bundler-common-2.2.0.jar%3D%2Fmaven.pomderived%3D%2Ftrue%3D%2F%3D%2Fmaven.groupId%3D%2Fio.quarkiverse.web-bundler%3D%2F%3D%2Fmaven.artifactId%3D%2Fquarkus-web-bundler-common%3D%2F%3D%2Fmaven.version%3D%2F2.2.0%3D%2F%3D%2Fmaven.scope%3D%2Fcompile%3D%2F%3D%2Fmaven.pomderived%3D%2Ftrue%3D%2F

		// Qute JDT generate this uri
		// jdt://jarentry/templates/tags/bundle.html?=the-code-site/C:%5C/Users%5C/AngeloZerr%5C/.m2%5C/repository%5C/io%5C/quarkiverse%5C/web-bundler%5C/quarkus-web-bundler-common%5C/2.2.0%5C/quarkus-web-bundler-common-2.2.0.jar=/maven.pomderived=/true=/=/maven.groupId=/io.quarkiverse.web-bundler=/=/maven.artifactId=/quarkus-web-bundler-common=/=/maven.version=/2.2.0=/=/maven.scope=/compile=/=/maven.pomderived=/true=/

		// Normalize those 2 uris
		if (uri == null)
			return null;
		try {
			// 1. Decode percent-encoded characters (%3D, %2F, etc.)
			String decoded = URLDecoder.decode(uri, StandardCharsets.UTF_8);
			// 2. Replace __xxx__ segments back to xxx (vscode-java encoding)
			decoded = decoded.replaceAll("__([^_]+)__", "$1");
			// 3. Normalize backslashes to forward slashes
			decoded = decoded.replace("\\", "/");
			return decoded;
		} catch (Exception e) {
			return uri;
		}
	}

	public IncludeUsagesRegistry getIncludeUsagesRegistry() {
		return includeUsagesRegistry;
	}

}