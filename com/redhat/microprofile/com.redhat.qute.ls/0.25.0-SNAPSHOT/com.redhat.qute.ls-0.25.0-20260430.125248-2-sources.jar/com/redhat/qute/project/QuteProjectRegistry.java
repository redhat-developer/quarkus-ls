/*******************************************************************************
* Copyright (c) 2021 Red Hat Inc. and others.
* All rights reserved. This program and the accompanying materials
* which accompanies this distribution, and is available at
* http://www.eclipse.org/legal/epl-v20.html
*
* SPDX-License-Identifier: EPL-2.0
*
* Contributors:
*     Red Hat Inc. - initial API and implementation
*******************************************************************************/
package com.redhat.qute.project;

import static com.redhat.qute.services.QuteCompletableFutures.EXTENDED_TEMPLATE_DATAMODEL_NULL_FUTURE;
import static com.redhat.qute.utils.FutureUtils.isFutureLoaded;

import java.nio.file.Path;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

import org.eclipse.lsp4j.DidChangeWatchedFilesParams;
import org.eclipse.lsp4j.FileChangeType;
import org.eclipse.lsp4j.FileEvent;
import org.eclipse.lsp4j.Location;

import com.redhat.qute.commons.FileUtils;
import com.redhat.qute.commons.JavaTypeInfo;
import com.redhat.qute.commons.ProjectInfo;
import com.redhat.qute.commons.QuteJavaDefinitionParams;
import com.redhat.qute.commons.QuteJavaTypesParams;
import com.redhat.qute.commons.QuteJavadocParams;
import com.redhat.qute.commons.QuteProjectParams;
import com.redhat.qute.commons.QuteResolvedJavaTypeParams;
import com.redhat.qute.commons.ResolvedJavaTypeInfo;
import com.redhat.qute.commons.binary.BinaryTemplateInfo;
import com.redhat.qute.commons.binary.QuteBinaryTemplateParams;
import com.redhat.qute.commons.datamodel.DataModelParameter;
import com.redhat.qute.commons.datamodel.DataModelProject;
import com.redhat.qute.commons.datamodel.DataModelTemplate;
import com.redhat.qute.commons.datamodel.JavaDataModelChangeEvent;
import com.redhat.qute.commons.datamodel.JavaDataModelChangeEvent.ProjectChangeInfo;
import com.redhat.qute.commons.datamodel.QuteDataModelProjectParams;
import com.redhat.qute.ls.api.QuteBinaryTemplateProvider;
import com.redhat.qute.ls.api.QuteDataModelProjectProvider;
import com.redhat.qute.ls.api.QuteJavaDefinitionProvider;
import com.redhat.qute.ls.api.QuteJavaTypesProvider;
import com.redhat.qute.ls.api.QuteJavadocProvider;
import com.redhat.qute.ls.api.QuteProjectInfoProvider;
import com.redhat.qute.ls.api.QuteResolvedJavaTypeProvider;
import com.redhat.qute.parser.template.Template;
import com.redhat.qute.project.datamodel.ExtendedDataModelTemplate;
import com.redhat.qute.project.datamodel.resolvers.MethodValueResolver;
import com.redhat.qute.project.datamodel.resolvers.ValueResolversRegistry;
import com.redhat.qute.project.documents.QuteOpenedTextDocument;
import com.redhat.qute.project.documents.TemplateValidator;
import com.redhat.qute.project.extensions.DidChangeWatchedFilesParticipant;
import com.redhat.qute.project.extensions.ProjectExtensionContext;
import com.redhat.qute.services.nativemode.JavaTypeFilter;
import com.redhat.qute.services.nativemode.ReflectionJavaTypeFilter;
import com.redhat.qute.settings.QuteNativeSettings;
import com.redhat.qute.settings.SharedSettings;

/**
 * Registry which hosts Qute project {@link QuteProject}.
 *
 * @author Angelo ZERR
 *
 */
public class QuteProjectRegistry
		implements QuteDataModelProjectProvider, QuteBinaryTemplateProvider, QuteJavadocProvider {

	private final ValueResolversRegistry valueResolversRegistry;

	private final Map<String /* project uri */, QuteProject> projects;

	private final QuteProjectInfoProvider projectInfoProvider;

	private final QuteResolvedJavaTypeProvider resolvedTypeProvider;

	private final QuteDataModelProjectProvider dataModelProvider;

	private final QuteBinaryTemplateProvider binaryTemplateProvider;

	private final QuteJavaTypesProvider javaTypeProvider;

	private final QuteJavaDefinitionProvider definitionProvider;

	private final QuteJavadocProvider javadocProvider;

	private final TemplateValidator validator;

	private final Supplier<ProgressSupport> progressSupportProvider;

	private final SharedSettings sharedSettings;
	private boolean didChangeWatchedFilesSupported;

	private boolean asyncValidation = true;

	private CompletableFuture<Collection<QuteProject>> loadQuteProjectsFuture;

	public QuteProjectRegistry(QuteProjectInfoProvider projectInfoProvider, QuteJavaTypesProvider javaTypeProvider,
			QuteJavaDefinitionProvider definitionProvider, QuteResolvedJavaTypeProvider resolvedClassProvider,
			QuteDataModelProjectProvider dataModelProvider, QuteBinaryTemplateProvider binaryTemplateProvider,
			QuteJavadocProvider javadocProvider, TemplateValidator validator,
			Supplier<ProgressSupport> progressSupportProvider,
			SharedSettings sharedSettings) {
		this.projectInfoProvider = projectInfoProvider;
		this.javaTypeProvider = javaTypeProvider;
		this.definitionProvider = definitionProvider;
		this.projects = new HashMap<>();
		this.resolvedTypeProvider = resolvedClassProvider;
		this.dataModelProvider = dataModelProvider;
		this.binaryTemplateProvider = binaryTemplateProvider;
		this.javadocProvider = javadocProvider;
		this.valueResolversRegistry = new ValueResolversRegistry();
		this.validator = validator;
		this.progressSupportProvider = progressSupportProvider;
		this.sharedSettings = sharedSettings;
	}

	/**
	 * Enable/disable did change watched file support.
	 *
	 * @param didChangeWatchedFilesSupported true if did changed file is supported
	 *                                       by the LSP client and false otherwise.
	 */
	public void setDidChangeWatchedFilesSupported(boolean didChangeWatchedFilesSupported) {
		this.didChangeWatchedFilesSupported = didChangeWatchedFilesSupported;
	}

	/**
	 * Returns true if did changed file is supported by the LSP client and false
	 * otherwise.
	 *
	 * @return true if did changed file is supported by the LSP client and false
	 *         otherwise.
	 */
	public boolean isDidChangeWatchedFilesSupported() {
		return didChangeWatchedFilesSupported;
	}

	/**
	 * Returns the Qute project by the given uri <code>projectUri</code> and null
	 * otherwise.
	 *
	 * @param projectUri the project Uri.
	 *
	 * @return the Qute project by the given uri <code>projectUri</code> and null
	 *         otherwise.
	 */
	public QuteProject getProject(String projectUri) {
		return projects.get(projectUri);
	}

	/**
	 * Returns the Qute project by the given info <code>projectInfo</code>.
	 *
	 * @param projectInfo the project information.
	 *
	 * @return the Qute project by the given info <code>projectInfo</code>.
	 */
	public QuteProject getProject(ProjectInfo projectInfo) {
		String projectUri = projectInfo.getUri();
		QuteProject project = getProject(projectUri);
		if (project == null) {
			project = registerProjectSync(projectInfo);
		}
		return project;
	}

	private synchronized QuteProject registerProjectSync(ProjectInfo projectInfo) {
		String projectUri = projectInfo.getUri();
		QuteProject project = getProject(projectUri);
		if (project != null) {
			return project;
		}
		project = createProject(projectInfo);
		registerProject(project);
		return project;
	}

	protected QuteProject createProject(ProjectInfo projectInfo) {
		return new QuteProject(projectInfo, this);
	}

	protected TemplateValidator getValidator() {
		return validator;
	}

	protected void registerProject(QuteProject project) {
		projects.put(project.getUri(), project);
	}

	/**
	 * Open a Qute template.
	 *
	 * @param document the Qute template.
	 */
	public void onDidOpenTextDocument(QuteTextDocument document) {
		QuteProject project = document.getProject();
		if (project != null) {
			project.onDidOpenTextDocument(document);
		}
	}

	/**
	 * Close a Qute template.
	 *
	 * @param document the Qute template.
	 */
	public void onDidCloseTextDocument(QuteTextDocument document) {
		QuteProject project = document.getProject();
		if (project != null) {
			project.onDidCloseTextDocument(document);
		}
	}

	public void onDidSaveTextDocument(QuteOpenedTextDocument document) {
		QuteProject project = document.getProject();
		if (project != null) {
			project.onDidSaveTextDocument(document);
		}
	}

	protected CompletableFuture<ResolvedJavaTypeInfo> getResolvedJavaType(QuteResolvedJavaTypeParams params) {
		return resolvedTypeProvider.getResolvedJavaType(params);
	}

	public void dataModelChanged(JavaDataModelChangeEvent event) {
		Set<ProjectChangeInfo> projects = event.getProjects();
		for (ProjectChangeInfo projectIndo : projects) {
			QuteProject project = getProject(projectIndo.getUri());
			if (project != null) {
				project.resetJavaTypes(projectIndo.getSources());
			}
		}
	}

	public CompletableFuture<ExtendedDataModelTemplate> getDataModelTemplate(Template template) {
		QuteProject existingProject = template.getProject();
		if (existingProject == null) {
			// The project uri is not already get (it occurs when Qute template is opened
			// and the project information takes some times).
			// Load the project information and call the data model.
			return template.getProjectFuture() //
					.thenCompose(projectInfo -> {
						if (projectInfo == null) {
							return EXTENDED_TEMPLATE_DATAMODEL_NULL_FUTURE;
						}
						QuteProject project = getProject(projectInfo);
						return project.getDataModelTemplate(template);
					});
		}
		return existingProject.getDataModelTemplate(template);
	}

	public CompletableFuture<List<JavaTypeInfo>> getJavaTypes(QuteJavaTypesParams params) {
		return javaTypeProvider.getJavaTypes(params);
	}

	public CompletableFuture<Location> getJavaDefinition(QuteJavaDefinitionParams params) {
		return definitionProvider.getJavaDefinition(params);
	}

	@Override
	public CompletableFuture<List<BinaryTemplateInfo>> getBinaryTemplates(QuteBinaryTemplateParams params) {
		return binaryTemplateProvider.getBinaryTemplates(params);
	}

	@Override
	public CompletableFuture<DataModelProject<DataModelTemplate<DataModelParameter>>> getDataModelProject(
			QuteDataModelProjectParams params) {
		return dataModelProvider.getDataModelProject(params);
	}

	/**
	 * Returns the commons value resolvers available for any Qute project.
	 * 
	 * @return the commons value resolvers available for any Qute project.
	 */
	List<MethodValueResolver> getCommmonsResolvers() {
		return valueResolversRegistry.getResolvers();
	}

	/**
	 * Returns the java type filter according the given root java type and the
	 * native mode.
	 *
	 * @param rootJavaType         the Java root type.
	 * @param nativeImagesSettings the native images settings.
	 *
	 * @return the java type filter according the given root java type and the
	 *         native mode.
	 */
	public JavaTypeFilter getJavaTypeFilter(String projectUri, QuteNativeSettings nativeImagesSettings) {
		if (nativeImagesSettings != null && nativeImagesSettings.isEnabled()) {
			if (projectUri != null) {
				QuteProject project = getProject(projectUri);
				if (project != null) {
					return project.getJavaTypeFilterInNativeMode();
				}
			}
		}
		return ReflectionJavaTypeFilter.INSTANCE;
	}

	@Override
	public CompletableFuture<String> getJavadoc(QuteJavadocParams params) {
		return javadocProvider.getJavadoc(params);
	}

	public QuteProject findProjectFor(Path path) {
		for (QuteProject project : projects.values()) {
			if (isBelongToProject(path, project)) {
				return project;
			}
		}
		return null;
	}

	private static boolean isBelongToProject(Path path, QuteProject project) {
		return (project.isInProjectFolder(path) || project.isInTemplateFolders(path)
				|| project.isInSourceFolders(path));
	}

	public Collection<QuteProject> getProjects() {
		return projects.values();
	}

	public void didChangeWatchedFiles(DidChangeWatchedFilesParams params) {
		Set<QuteProject> projectsToValidate = new HashSet<>();
		List<FileEvent> changes = params.getChanges();
		// For some reason, vscode fill changes with several FileEvent which are the
		// same
		// Filter it.
		Map<Path, Set<FileChangeType>> fileEvents = toFileEventMap(changes);
		for (Map.Entry<Path, Set<FileChangeType>> pathEvent : fileEvents.entrySet()) {
			Path filePath = pathEvent.getKey();
			Set<FileChangeType> changeTypes = pathEvent.getValue();
			QuteProject project = findProjectFor(filePath);
			if (project != null) {
				if (project.isInTemplateFolders(filePath)) {
					// Some qute templates are deleted, created, or changed
					// Collect impacted Qute projects
					Path templatePath = filePath;
					QuteTextDocument updatedDocument = project.findSourceDocument(templatePath);
					if (updatedDocument != null && updatedDocument.isOpened()) {
						projectsToValidate.add(project);
					} else {
						// In case of closed document, we collect the project and update the cache
						if (changeTypes.contains(FileChangeType.Changed)
								|| changeTypes.contains(FileChangeType.Created)) {
							// The template is created, update the cache and collect the project
							updatedDocument = project.onDidCreateTemplate(templatePath);
							if (updatedDocument != null) {
								projectsToValidate.add(updatedDocument.getProject());
							}
						} else if (changeTypes.contains(FileChangeType.Deleted)) {
							// The template is deleted, update the cache, collect the project and publish
							// empty diagnostics for this file
							updatedDocument = project.onDidDeleteTemplate(templatePath);
							if (validator != null) {
								// Clear diagnostics for the deleted file in this case.
								validator.clearDiagnosticsFor(FileUtils.toUri(filePath));
							}
							projectsToValidate.add(project);
						}
					}

					if (updatedDocument != null && updatedDocument.isUserTag()) {
						// User tag has been created, deleted, modified, all templates from project
						// dependencies must also
						// be triggered.
						for (QuteProject p : this.projects.values()) {
							if (p != project && p.getProjectDependencies().contains(project)) {
								projectsToValidate.add(p);
							}
						}
					}
				}
				ProjectExtensionContext context = new ProjectExtensionContext();
				for (DidChangeWatchedFilesParticipant participant : project.getDidChangeWatchedFilesParticipants()) {
					if (participant.isEnabled()) {
						if (participant.didChangeWatchedFile(filePath, changeTypes, context)) {
							projectsToValidate.add(project);
						}
					}
				}
				context.reparseTemplates();
			}
		}

		if (projectsToValidate.isEmpty()) {
			return;
		}

		// trigger validation for all opened and closed Qute template files which belong
		// to the project list.
		if (validator != null) {
			validator.triggerValidationFor(projectsToValidate);
		}
	}

	private Map<Path, Set<FileChangeType>> toFileEventMap(List<FileEvent> changes) {
		Map<Path, Set<FileChangeType>> result = new HashMap<>();
		for (FileEvent fileEvent : changes) {
			String fileUri = fileEvent.getUri();
			Path filePath = FileUtils.createPath(fileUri);
			if (filePath != null) {
				Set<FileChangeType> changeTypes = result.get(filePath);
				if (changeTypes == null) {
					changeTypes = new HashSet<>();
					result.put(filePath, changeTypes);
				}
				changeTypes.add(fileEvent.getType());
			}
		}
		return result;
	}

	public void dispose() {
		for (QuteProject project : projects.values()) {
			project.dispose();
		}
	}

	public CompletableFuture<ProjectInfo> getProjectInfo(QuteProjectParams params) {
		return projectInfoProvider.getProjectInfo(params);
	}

	public CompletableFuture<Collection<QuteProject>> loadQuteProjects() {
		if (isQuteProjectLoaded()) {
			return loadQuteProjectsFuture;
		}
		return loadQuteProjectsSync();
	}

	private synchronized CompletableFuture<Collection<QuteProject>> loadQuteProjectsSync() {
		if (isQuteProjectLoaded()) {
			return loadQuteProjectsFuture;
		}

		ProgressSupport progressSupport = getProgressSupportProvider().get();
		ProgressContext progressContext = progressSupport != null ? new ProgressContext(progressSupport) : null;
		if (progressContext != null) {
			progressContext.startProgress("Loading Qute projects from workspace.",
					"Collecting Qute projects from workspace.");
		}

		return loadQuteProjectsFuture = projectInfoProvider //
				.getProjects() //
				.thenCompose(projects -> {
					if (projects != null && !projects.isEmpty()) {
						// There are some Qute projects in the workspace, load them
						return this.loadQuteProjects(projects, progressContext) //
								.thenApply(loadedProjects -> {
									if (progressContext != null) {
										progressContext.endProgress();
									}
									return loadedProjects;
								})//
								.exceptionally((a) -> {
									if (progressContext != null) {
										progressContext.endProgress();
									}
									return Collections.emptyList();
								});
					}
					if (progressContext != null) {
						progressContext.endProgress();
					}
					return CompletableFuture.completedFuture(Collections.emptyList());
				}) //
				.exceptionally((a) -> {
					if (progressContext != null) {
						progressContext.endProgress();
					}
					return Collections.emptyList();
				});
	}

	private boolean isQuteProjectLoaded() {
		return isFutureLoaded(loadQuteProjectsFuture);
	}

	private CompletableFuture<Collection<QuteProject>> loadQuteProjects(Collection<ProjectInfo> projects,
			ProgressContext progressContext) {
		// 1. Create all projects first so that dependency references can be resolved.
		for (ProjectInfo projectInfo : projects) {
			getProject(projectInfo);
		}

		// 2. Inject dependencies BEFORE starting the load so that
		// QuteProject.waitForDependencies() can find them immediately.
		for (ProjectInfo projectInfo : projects) {
			QuteProject project = getProject(projectInfo.getUri());
			if (project == null) {
				continue;
			}
			if (projectInfo.getProjectDependencyUris() != null) {
				for (String depUri : projectInfo.getProjectDependencyUris()) {
					QuteProject dep = getProject(depUri);
					if (dep != null) {
						project.addProjectDependency(dep);
					}
				}
			}
		}

		AtomicInteger increment = new AtomicInteger();
		int delta = projects.isEmpty() ? 100 : 100 / projects.size();

		// 3. Start loading all projects — projectDependencies is already populated.
		CompletableFuture<QuteProject>[] futures = new CompletableFuture[projects.size()];
		int i = 0;
		for (ProjectInfo projectInfo : projects) {
			QuteProject project = getProject(projectInfo.getUri());
			CompletableFuture<QuteProject> future = project.load();
			future.thenApply(p -> {
				if (progressContext != null) {
					progressContext.report("Qute project '" + project.getUri() + "' loaded.",
							increment.addAndGet(delta));
				}
				return null;
			});
			futures[i++] = future;
		}

		return CompletableFuture.allOf(futures).thenApply(_unused -> this.projects.values());
	}

	public void projectAdded(ProjectInfo projectInfo) {
		// Create the project if it does not exist yet.
		QuteProject project = getProject(projectInfo);

		// Inject dependencies before load() so that waitForDependencies()
		// can resolve them without any external signalling mechanism.
		if (projectInfo.getProjectDependencyUris() != null) {
			for (String depUri : projectInfo.getProjectDependencyUris()) {
				QuteProject dep = getProject(depUri);
				if (dep != null) {
					project.addProjectDependency(dep);
				}
			}
		}
		project.load();
	}

	public void projectRemoved(ProjectInfo projectInfo) {
		String projectUri = projectInfo.getUri();
		QuteProject project = getProject(projectUri);
		if (project != null) {
			project.dispose();
			projects.remove(projectUri);
		}
	}

	public void setAsyncValidation(boolean asyncValidation) {
		this.asyncValidation = asyncValidation;
	}

	public boolean isAsyncValidation() {
		return asyncValidation;
	}

	public CompletableFuture<QuteTextDocument> getBinaryDocument(String uri) {
		return loadQuteProjects() //
				.thenApply(projects -> {
					for (QuteProject project : projects) {
						QuteTextDocument document = project.getBinaryDocument(uri);
						if (document != null) {
							return document;
						}
					}
					return null;
				});
	}

	public Supplier<ProgressSupport> getProgressSupportProvider() {
		return progressSupportProvider;
	}
	
	public SharedSettings getSharedSettings() {
		return sharedSettings;
	}
}